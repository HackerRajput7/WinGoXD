const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: 'localhost',
    user: 'wingoxd',
    password: 'wingoxd',
    database: 'wingoxd'
});


export default connection;